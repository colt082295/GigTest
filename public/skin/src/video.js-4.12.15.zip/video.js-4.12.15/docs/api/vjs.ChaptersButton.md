<!-- GENERATED FROM SOURCE -->

# vjs.ChaptersButton

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L451](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L451)  

The button component for toggling and selecting chapters

---

