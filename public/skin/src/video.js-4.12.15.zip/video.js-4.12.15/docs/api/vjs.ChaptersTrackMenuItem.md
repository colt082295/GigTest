<!-- GENERATED FROM SOURCE -->

# vjs.ChaptersTrackMenuItem

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L550](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L550)  

---

