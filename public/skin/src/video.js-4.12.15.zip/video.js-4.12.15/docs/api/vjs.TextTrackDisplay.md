<!-- GENERATED FROM SOURCE -->

# vjs.TextTrackDisplay

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L13](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L13)  

The component for displaying text track cues

---

