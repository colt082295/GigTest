<!-- GENERATED FROM SOURCE -->

# vjs.TextTrackButton

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L337](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L337)  

The base class for buttons that toggle specific text track types (e.g. subtitles)

---

